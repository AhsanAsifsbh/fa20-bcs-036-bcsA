const mongoose = require("mongoose");
let modelSchema = mongoose.Schema({
  name: String,
  qualifications: String,
  expertise: String,
});
let Model = mongoose.model("Teacher", modelSchema);
module.exports = Model;