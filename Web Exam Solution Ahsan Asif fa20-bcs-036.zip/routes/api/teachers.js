const express = require("express");
const Teacher = require("../../models/Teacher");
let router = express.Router();
router.post("/api/teachers", async function (req, res) {
  let record = new Teacher(req.body);
  await record.save();
  res.send(record);
});

router.put("/api/teachers/:id", async function (req, res) {
  //   return res.send(req.body);
  let record = await Teacher.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
  });
  res.send(record);
});
router.delete("/api/teachers/:id", async function (req, res) {
  let record = await Teacher.findByIdAndDelete(req.params.id);
  res.send("Done");
});
router.get("/api/teachers/:id", async function (req, res) {
  let record = await Teacher.findById(req.params.id);
  res.send(record);
});
router.get("/api/teachers", async function (req, res) {
  let records = await Teacher.find();
  res.send(records);
});

module.exports = router;