console.clear();
const express = require("express");
const app = express();
const port = 3000;

var expressLayouts = require("express-ejs-layouts");

app.use(express.json());
app.set("view engine", "ejs");


app.use("/form", (req, res, next) => {
  res.render("form");
});
app.use("/", (req, res, next) => {
  res.render("layout.ejs");
});




const mongoose = require("mongoose");
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

//  Mongoose connection
// const MONGODBURL = "mongodb+srv://Ahsan:abcdz1234@atlascluster.ffpyhgc.mongodb.net/";
const MONGODBURL =
  "mongodb+srv://Ahsan:boss123%40@atlascluster.ffpyhgc.mongodb.net/";
mongoose
  .connect(MONGODBURL, { useNewUrlParser: true })
  .then(() => console.log("Connected to Mongo ...."))
  .catch((error) => console.log(error.message));
